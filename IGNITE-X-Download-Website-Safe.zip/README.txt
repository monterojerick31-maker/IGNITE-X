IGNITE-X DOWNLOAD WEBSITE

Files:
- index.html                  Main mobile-friendly download page
- downloads/IGNITE-X.apk      Supplied APK
- assets/ignite-x-logo.png     Supplied logo
- QR-CODE-REPLACE-URL.png     Placeholder QR

IMPORTANT:
The QR code currently contains https://YOUR-DOMAIN.com/ignite-x/.
After you choose a real public URL, generate a new QR code containing that exact URL.
The APK link is relative, so it will work automatically when this folder is deployed as a website.

Deployment:
Upload the contents of this folder to your web host. Make sure the APK remains at:
downloads/IGNITE-X.apk
